# krl_rover

A simple Python library to control a rover using a Raspberry Pi.

## Installation

You can install the library via pip:

```bash
pip install krl_rover
