# krl_rover/__init__.py

from .rover_control import Rover
